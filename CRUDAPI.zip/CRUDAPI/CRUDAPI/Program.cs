using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

var users = new List<User>()
{
    new User { Username = "User1", UserAge = 24},
    new User { Username = "User2", UserAge = 32},
};

// Logging Middleware
app.Use(async (context, next) =>
{
    Console.WriteLine($"Incoming request: {context.Request.Method} {context.Request.Path}");
    await next.Invoke();
    Console.WriteLine($"Outgoing response: {context.Response.StatusCode}");
});

// Authentication Middleware
app.Use(async (context, next) =>
{
    var authHeader = context.Request.Headers["Authorization"].FirstOrDefault();
    if (authHeader == null || authHeader != "Bearer mysecrettoken")
    {
        context.Response.StatusCode = 401;
        await context.Response.WriteAsync("Unauthorized123");
        return;
    }

    await next.Invoke();
});
// Basic routes
app.MapGet("/", () => "Welcome to the Simple Web API!");

app.MapGet("/users", () =>
{
    return users;
});
app.MapGet("/users/{username}", (string username) =>
{
    User? user = users.FirstOrDefault(u => u.Username == username);
    return user != null ? Results.Ok(user) : Results.NotFound();
});

app.MapPost("/users", (User user) =>
{
    ValidationContext validationContext = new ValidationContext(user);
    List<ValidationResult> validationResults = [];

    if (!Validator.TryValidateObject(user, validationContext, validationResults, true))
    {
        return Results.BadRequest(validationResults);
    }

    users.Add(user);
    return Results.Created($"/users/{user.Username}", user);
    //return Results.Created($"/users/{users.Count -1}", user);
});

app.MapDelete("/users/{username}", (string username) =>
{
    User? user = users.FirstOrDefault(u => u.Username == username);
    if (user == null)
    {
        return Results.NotFound();
    }

    users.Remove(user);
    return Results.NoContent();
});
app.MapPut("/users/{username}", (string username, User updatedUser) =>
{
    User? user = users.FirstOrDefault(u => u.Username == username);
    if (user == null)
    {
        return Results.NotFound();
    }

    ValidationContext validationContext = new ValidationContext(updatedUser);
    List<ValidationResult> validationResults = [];

    if (!Validator.TryValidateObject(updatedUser, validationContext, validationResults, true))
    {
        return Results.BadRequest(validationResults);
    }

    user.Username = updatedUser.Username;
    user.UserAge = updatedUser.UserAge;
    return Results.Ok(user);
});
app.Run();

public class User
{
    // [Required]
    public required string Username { get; set; }

    // [Range(1, 150, ErrorMessage = "UserAge must be between 1 and 150.")]
    public int UserAge { get; set; }
}